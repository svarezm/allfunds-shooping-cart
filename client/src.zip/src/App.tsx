import Shop from './pages/Shop';
import { Box } from '@mui/material';

function App() {
  return (
    <Box>
      <Shop />
    </Box>
  );
}

export default App;