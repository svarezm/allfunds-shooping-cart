export interface Product {
    id: string
    productName: string
    image_url: string
    price: number
    stock: number
    favorite?: boolean
  }
  