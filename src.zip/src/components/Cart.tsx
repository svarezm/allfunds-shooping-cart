import { useCart } from '../context/CartContext';
import {
    Box,
    Typography,
    Button,
    Card,
    CardContent,
    CardMedia,
    CardActions,
    Stack,
    useMediaQuery,
    IconButton
} from '@mui/material';
import RemoveShoppingCartIcon from '@mui/icons-material/RemoveShoppingCart';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';

export default function Cart() {
    const { cart, updateQuantity, removeFromCart, getCartTotal } = useCart();
    const isMobile = useMediaQuery('(max-width: 768px)');

    if (cart.length === 0) {
        return (
            <Box p={2} textAlign="center">
                <RemoveShoppingCartIcon sx={{ fontSize: 50, color: 'gray' }} />
                <Typography variant={isMobile ? 'h6' : 'h5'}>Your cart is empty</Typography>
            </Box>
        );
    }

    return (
        <Box p={2}>
            <Typography variant={isMobile ? 'h5' : 'h4'} gutterBottom>
                Your Cart
            </Typography>

            <Stack spacing={2}>
                {cart.map(({ product, quantity }) => (
                    <Card key={product.id} sx={{ display: 'flex', alignItems: 'stretch' }}>
                        <CardMedia
                            component="img"
                            sx={{
                                width: isMobile ? 80 : 140,
                                height: '100%',
                                objectFit: 'cover',
                                marginRight: 2
                            }}
                            image={product.image_url}
                            alt={product.productName}
                        />
                        <Box sx={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
                            <CardContent sx={{ flex: '1 0 auto', padding: '8px' }}>
                                <Typography variant={isMobile ? 'body1' : 'h6'}>{product.productName}</Typography>
                                <Typography variant="body2" color="text.secondary">
                                    Price: €{product.price.toFixed(2)}
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    Subtotal: €{(product.price * quantity).toFixed(2)}
                                </Typography>
                            </CardContent>
                            <CardActions sx={{ padding: '8px', display: 'flex', alignItems: 'center' }}>
                                <IconButton
                                    size="small"
                                    onClick={() => updateQuantity(product.id, quantity - 1)}
                                >
                                    <RemoveIcon />
                                </IconButton>
                                <Typography>{quantity}</Typography>
                                <IconButton
                                    size="small"
                                    onClick={() => updateQuantity(product.id, quantity + 1)}
                                >
                                    <AddIcon />
                                </IconButton>
                                <IconButton
                                    size="small"
                                    color="error"
                                    onClick={() => removeFromCart(product.id)}
                                >
                                    <RemoveShoppingCartIcon />
                                </IconButton>
                            </CardActions>
                        </Box>
                    </Card>
                ))}
            </Stack>

            <Box mt={4} display="flex" justifyContent="space-between" alignItems="center">
                <Typography variant={isMobile ? 'body1' : 'h6'}>
                    Total: €{getCartTotal().toFixed(2)}
                </Typography>
                <Button variant="contained" color="primary">
                    Checkout
                </Button>
            </Box>
        </Box>
    );
}
